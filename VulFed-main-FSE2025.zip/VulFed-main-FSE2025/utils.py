import torch
from dataprocess.builddataset import *
from random import shuffle
from torch.utils.data import Subset
from sklearn.model_selection import train_test_split
import numpy as np
from collections import defaultdict

def averlist_traintest(dataset, testratio=0.2, random_state=None):
    labels = [label for _, label in dataset]
    indices_train, indices_test = train_test_split(
        range(len(labels)), test_size=testratio, stratify=labels, random_state=random_state
    )
    train_dataset = Subset(dataset, indices_train)
    test_dataset = Subset(dataset, indices_test)
    return train_dataset, test_dataset


def calc_weight(dataset, length=2):
    total = len(dataset)
    weight = []
    for i in range(length):
        weight.append(0)
    for _, label in dataset:
        weight[label] += 1

    return torch.tensor(list(map(lambda v: total / v, weight)))


def iid(dataset, num_users):
    num_items = int(len(dataset) / num_users)
    dict_users, all_idxs = {}, [i for i in range(len(dataset))]
    for i in range(num_users):
        dict_users[i] = set(np.random.choice(all_idxs, num_items, replace=False))
        all_idxs = list(set(all_idxs) - dict_users[i])

    for i in range(num_users):
        dict_users[i] = np.array(list(dict_users[i])).tolist()

    return dict_users


def noniid(dataset, num_users, num_classes, alpha):
    train_labels = []
    for i in dataset:
        train_labels.append(i[1])
    train_labels = np.array(train_labels)
    label_distribution = np.random.dirichlet([alpha]*num_users, num_classes)

    class_idcs = [np.argwhere(train_labels == y).flatten()
                  for y in range(num_classes)]

    client_idcs = [[] for _ in range(num_users)]
    for k_idcs, fracs in zip(class_idcs, label_distribution):
        for i, idcs in enumerate(np.split(k_idcs,
                                          (np.cumsum(fracs)[:-1]*len(k_idcs)).astype(int)
                                 )):
            client_idcs[i] += [idcs]

    client_idcs = [np.concatenate(idcs) for idcs in client_idcs]
    return client_idcs


def getsubset(dataset, ratio = 0.1):

    class_counts = defaultdict(int)
    for i in dataset:
        class_counts[i[1]] += 1

    total_samples = len(dataset)
    class_ratios = {label: count / total_samples for label, count in class_counts.items()}

    slice = 0.1
    subset_class_counts = {label: int(slice * count * total_samples) for label, count in class_ratios.items()}

    subset_indices = []
    subset_class_counter = defaultdict(int)
    for i, (data, label) in enumerate(dataset):
        if subset_class_counter[label] < subset_class_counts[label]:
            subset_indices.append(i)
            subset_class_counter[label] += 1

    subset_train = Subset(dataset, subset_indices)

    return subset_train

