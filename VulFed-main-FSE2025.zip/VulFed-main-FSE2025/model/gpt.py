from torch import nn
import torch
import transformers



class gpt2_BatchTextCall(object):
    """call function for tokenizing and getting batch text
    """

    def __init__(self, tokenizer, max_len=312):
        self.tokenizer = tokenizer
        self.max_len = max_len

    def text2id(self, batch_text):
        return self.tokenizer(batch_text, max_length=self.max_len,
                              truncation=True, padding='max_length', return_tensors='pt')

    def __call__(self, batch):
        batch_text = [item[0] for item in batch]
        batch_label = [item[1] for item in batch]

        source = self.text2id(batch_text)
        token = source.get('input_ids').squeeze(1)
        mask = source.get('attention_mask').squeeze(1)
        label = torch.tensor(batch_label)

        return token, mask, label

class gpt2_MultiClass(nn.Module):
    """ text processed by bert model encode and get cls vector for multi classification
    """

    def __init__(self, gpt_encode_model, model_config, num_classes=2, pooling_type='cls'):

        super(gpt2_MultiClass, self).__init__()
        self.gpt = gpt_encode_model
        self.num_classes = num_classes
        self.fc = nn.Linear(model_config.hidden_size, num_classes)
        self.pooling = pooling_type

    def forward(self, batch_token):
        # with torch.no_grad():
        out = self.gpt(batch_token)
        # print(out)

        if self.pooling == 'cls':
            out = out.last_hidden_state[:, 0, :]  # [batch, 768]
        else:
            raise "should define pooling type first!"

        out_fc = self.fc(out)
        return out_fc