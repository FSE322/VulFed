from torch import nn
import torch
import transformers

class Bert_for_Peft(nn.Module):
    def __init__(self, model):
        super(Bert_for_Peft, self).__init__()
        self.bert = model

    def forward(self, batch_token, batch_attention_mask):
        out = self.bert(batch_token,
                        attention_mask=batch_attention_mask,
                        output_hidden_states=True)
        out = out.logits
        return out