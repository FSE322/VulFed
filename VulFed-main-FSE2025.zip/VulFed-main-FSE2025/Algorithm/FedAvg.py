import copy
import numpy as np
from Algorithm.method import *
from utils import *
import torch
from torch.utils.data import ConcatDataset, DataLoader
from tqdm import tqdm


def FedAvg_bert(net_glob, dataset_train, dataset_test, dict_users, args, call, label_dict=None):

    net_glob.train()

    # training
    acc, pre, rec, f1 = [], [], [], []
    weight = calc_weight(ConcatDataset([dataset_train, dataset_test]), args.num_classes)

    for iter in range(args.epochs):
        print('*'*80)
        print('Round {:3d}'.format(iter))
        w_locals = []
        lens = []
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)
        for idx in tqdm(idxs_users, desc='Training...'):
            local = LocalUpdate_FedAvg_bert(args=args, call=call, weight=weight, dataset=dataset_train, idxs=dict_users[idx])
            w = local.train(model=copy.deepcopy(net_glob).to(args.device), args=args)

            w_locals.append(copy.deepcopy(w))
            lens.append(len(dict_users[idx]))

        # update global weights

        w_glob = Aggregation(w_locals, lens)

        # copy weight to net_glob
        net_glob.load_state_dict(w_glob)

        acc_one, pre_one, rec_one, f1_one, metric_one = test_bert(net_glob, dataset_test, args, call)
        acc.append(acc_one)
        pre.append(pre_one)
        rec.append(rec_one)
        f1.append(f1_one)
        print("\nacc:"+str(acc_one))
        print("precision:" + str(pre_one))
        print("recall:" + str(rec_one))
        print("f1:" + str(f1_one))

        if args.cwecase == 0:
            print(metric_one)
        else:
            for i in range(len(metric_one)):
                acc_i = metric_one[i][i] / sum(metric_one[i])
                if i == 0:
                    print("FP：{}".format(1-acc_i))
                else:
                    cweclass = [key for key, val in label_dict.items() if val == (i-1)]
                    print("{}TP：{}".format(cweclass[0], acc_i))


    save_result(acc, 'test_acc', args)
    save_result(pre, 'test_pre', args)
    save_result(rec, 'test_rec', args)
    save_result(f1, 'test_f1', args)



class LocalUpdate_FedAvg_bert(object):
    def __init__(self, args, call, weight, dataset=None, idxs=None):
        self.args = args
        self.loss_func = torch.nn.CrossEntropyLoss(weight=weight.to(args.device))
        self.train_loader = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, collate_fn=call)

    def train(self, model, args):
        model.train()

        optimizer = torch.optim.AdamW(model.parameters(), lr=self.args.lr)

        for iter in range(self.args.local_ep):

            if args.model == 'bert':
                for i, (data, segment, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    segment = segment.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, segment, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif args.model == 'codebert':
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 'gpt') or (args.model == 'opt'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data)
                    loss = self.loss_func(outputs.logits, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 't5') or (args.model =='codet5'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask, decoder_input_ids=data)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()

        return model.state_dict()
