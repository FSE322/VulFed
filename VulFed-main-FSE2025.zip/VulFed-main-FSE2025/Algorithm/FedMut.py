import copy
import numpy as np
from Algorithm.method import *
from utils import *
import torch
from torch.utils.data import ConcatDataset, DataLoader
from tqdm import tqdm
import random


radius = 2.0
min_radius = 0.1
mut_acc_rate = 0.3
mut_bound = 50


def FedMut_bert(net_glob, dataset_train, dataset_test, dict_users, args, call, label_dict=None):
    net_glob.train()
    acc, pre, rec, f1 = [], [], [], []
    w_locals = []
    sim_arr = []
    weight = calc_weight(ConcatDataset([dataset_train, dataset_test]), args.num_classes)

    m = max(int(args.frac * args.num_users), 1)
    for i in range(m):
        w_locals.append(copy.deepcopy(net_glob.state_dict()))

    delta_list = []
    max_rank = 0
    w_old = copy.deepcopy(net_glob.state_dict())
    w_old_s1 = copy.deepcopy(net_glob.state_dict())

    for iter in range(args.epochs):
        w_old = copy.deepcopy(net_glob.state_dict())
        print('*' * 80)
        print('Round {:3d}'.format(iter))

        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)
        for i, idx in tqdm(enumerate(idxs_users), desc='training...'):
            net_glob.load_state_dict(w_locals[i])
            local = LocalUpdate_FedMut_bert(args=args, call=call, weight=weight, dataset=dataset_train, idxs=dict_users[idx])
            w = local.train(model=copy.deepcopy(net_glob).to(args.device), args=args)
            w_locals[i] = copy.deepcopy(w)

        # update global weights
        w_glob = Aggregation(w_locals, None)  # Global Model Generation

        # copy weight to net_glob
        net_glob.load_state_dict(w_glob)

        acc_one, pre_one, rec_one, f1_one, metric_one = test_bert(net_glob, dataset_test, args, call)
        acc.append(acc_one)
        pre.append(pre_one)
        rec.append(rec_one)
        f1.append(f1_one)
        print("\nacc:" + str(acc_one))
        print("precision:" + str(pre_one))
        print("recall:" + str(rec_one))
        print("f1:" + str(f1_one))

        w_delta = FedSub(w_glob, w_old, 1.0)
        rank = delta_rank(args, w_delta)
        if rank > max_rank:
            max_rank = rank
        alpha = radius
        # alpha = min(max(args.radius, max_rank/rank),(10.0-args.radius) * (1 - iter/args.epochs) + args.radius)
        w_locals = mutation_spread(args, iter, w_glob, w_old, w_locals, m, w_delta, alpha)

        if args.cwecase == 0:
            print(metric_one)
        else:
            for i in range(len(metric_one)):
                acc_i = metric_one[i][i] / sum(metric_one[i])
                if i == 0:
                    print("FP：{}".format(1-acc_i))
                else:
                    cweclass = [key for key, val in label_dict.items() if val == (i-1)]
                    print("{}TP：{}".format(cweclass[0], acc_i))


    save_result(acc, 'test_acc', args)
    save_result(pre, 'test_pre', args)
    save_result(rec, 'test_rec', args)
    save_result(f1, 'test_f1', args)


class LocalUpdate_FedMut_bert(object):
    def __init__(self, args, call, weight, dataset=None, idxs=None):
        self.args = args
        self.loss_func = torch.nn.CrossEntropyLoss(weight=weight.to(args.device))
        self.train_loader = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, collate_fn=call)

    def train(self, model, args):
        model.train()

        optimizer = torch.optim.AdamW(model.parameters(), lr=self.args.lr)

        for iter in range(self.args.local_ep):

            if args.model == 'bert':
                for i, (data, segment, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    segment = segment.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, segment, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif args.model == 'codebert':
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 'gpt') or (args.model == 'opt'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data)
                    loss = self.loss_func(outputs.logits, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 't5') or (args.model =='codet5'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask, decoder_input_ids=data)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()

        return model.state_dict()





def mutation_spread(args, iter, w_glob, w_old, w_locals, m, w_delta, alpha):
    # w_delta = FedSub(w_glob,w_old,(args.radius - args.min_radius) * (1.0 - iter/args.epochs) + args.min_radius)
    # if iter/args.epochs > 0.5:
    #     w_delta = FedSub(w_glob,w_old,(args.radius - args.min_radius) * (1.0 - iter/args.epochs)*2 + args.min_radius)
    # else:
    # w_delta = FedSub(w_glob,w_old,(args.radius - args.min_radius) * (iter/args.epochs)*2 + args.min_radius)
    # w_delta = FedSub(w_glob, w_old, args.radius)

    w_locals_new = []
    ctrl_cmd_list = []
    ctrl_rate = mut_acc_rate * (1.0 - min(iter * 1.0 / mut_bound, 1.0))

    for k in w_glob.keys():
        ctrl_list = []
        for i in range(0, int(m / 2)):
            ctrl = random.random()
            if ctrl > 0.5:
                ctrl_list.append(1.0)
                ctrl_list.append(1.0 * (-1.0 + ctrl_rate))
            else:
                ctrl_list.append(1.0 * (-1.0 + ctrl_rate))
                ctrl_list.append(1.0)
        random.shuffle(ctrl_list)
        ctrl_cmd_list.append(ctrl_list)
    cnt = 0
    for j in range(m):
        w_sub = copy.deepcopy(w_glob)
        if not (cnt == m - 1 and m % 2 == 1):
            ind = 0
            for k in w_sub.keys():
                w_sub[k] = w_sub[k] + w_delta[k] * ctrl_cmd_list[ind][j] * alpha
                ind += 1
        cnt += 1
        w_locals_new.append(w_sub)

    return w_locals_new


def FedSub(w, w_old, weight):
    w_sub = copy.deepcopy(w)
    for k in w_sub.keys():
        w_sub[k] = (w[k] - w_old[k]) * weight

    return w_sub


def delta_rank(args, delta_dict):
    cnt = 0
    dict_a = torch.Tensor(0)
    s = 0
    for p in delta_dict.keys():
        a = delta_dict[p]
        a = a.view(-1)
        if cnt == 0:
            dict_a = a
        else:
            dict_a = torch.cat((dict_a, a), dim=0)

        cnt += 1
        # print(sim)
    s = torch.norm(dict_a, dim=0)
    return s