import copy
import numpy as np
from Algorithm.method import *
from utils import *
import torch
from torch.utils.data import ConcatDataset, DataLoader
from tqdm import tqdm

import torch
from torch import nn, autograd
from torch.utils.data import DataLoader, Dataset
import torch.nn.functional as F
import numpy as np



def Moon_bert(net_glob, dataset_train, dataset_test, dict_users, args, call, label_dict=None):

    net_glob.train()

    # generate list of local models for each user
    net_local_list = []
    w_locals = {}
    for user in range(args.num_users):
        w_local_dict = {}
        for key in net_glob.state_dict().keys():
            w_local_dict[key] = net_glob.state_dict()[key]
        w_locals[user] = w_local_dict

    old_nets_pool = [[] for i in range(args.num_users)]

    acc, pre, rec, f1 = [], [], [], []
    weight = calc_weight(ConcatDataset([dataset_train, dataset_test]), args.num_classes)

    lens = [len(datasets) for _,datasets in dict_users.items()]

    for iter in range(args.epochs):

        print('*' * 80)
        print('Round {:3d}'.format(iter))

        w_glob = {}
        total_len = 0
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)
        for idx in tqdm(idxs_users, desc='Training...'):
            local = LocalUpdate_Moon_bert(args=args, call=call, weight=weight, glob_model=net_glob, old_models=old_nets_pool[idx],
                                     dataset=dataset_train, idxs=dict_users[idx])

            net_local = copy.deepcopy(net_glob)
            w_local = net_local.state_dict()
            net_local.load_state_dict(w_local)

            w_local = local.train(net_local.to(args.device), args)

            # update global weights
            if len(w_glob) == 0:
                w_glob = copy.deepcopy(w_local)
                for k, key in enumerate(net_glob.state_dict().keys()):
                    w_glob[key] = w_glob[key] * lens[idx]
                    w_locals[idx][key] = w_local[key]
            else:
                for k, key in enumerate(net_glob.state_dict().keys()):
                    w_glob[key] += w_local[key] * lens[idx]
                    w_locals[idx][key] = w_local[key]

            total_len += len(dict_users[idx])

            if len(old_nets_pool[idx]) < 1:
                old_net = copy.deepcopy(net_local)
                old_net.eval()
                for param in old_net.parameters():
                    param.requires_grad = False
                old_nets_pool[idx].append(old_net)
            elif 'FIFO' == 'FIFO':
                old_net = copy.deepcopy(net_local)
                old_net.eval()
                for param in old_net.parameters():
                    param.requires_grad = False
                for i in range(-1, -1, -1):
                    old_nets_pool[idx][i] = old_nets_pool[idx][i + 1]
                old_nets_pool[idx][0] = old_net

        # get weighted average for global weights
        for k in net_glob.state_dict().keys():
            w_glob[k] = torch.div(w_glob[k], total_len)

        # copy weight to net_glob
        net_glob.load_state_dict(w_glob)

        acc_one, pre_one, rec_one, f1_one, metric_one = test_bert(net_glob, dataset_test, args, call)
        acc.append(acc_one)
        pre.append(pre_one)
        rec.append(rec_one)
        f1.append(f1_one)
        print("\nacc:" + str(acc_one))
        print("precision:" + str(pre_one))
        print("recall:" + str(rec_one))
        print("f1:" + str(f1_one))

        if args.cwecase == 0:
            print(metric_one)
        else:
            for i in range(len(metric_one)):
                acc_i = metric_one[i][i] / sum(metric_one[i])
                if i == 0:
                    print("FP：{}".format(1-acc_i))
                else:
                    cweclass = [key for key, val in label_dict.items() if val == (i-1)]
                    print("{}TP：{}".format(cweclass[0], acc_i))


    save_result(acc, 'test_acc', args)
    save_result(pre, 'test_pre', args)
    save_result(rec, 'test_rec', args)
    save_result(f1, 'test_f1', args)



class LocalUpdate_Moon_bert(object):
    def __init__(self, args, call, weight, glob_model, old_models, dataset=None, idxs=None, verbose=False):
        self.args = args
        self.loss_func1 = nn.CrossEntropyLoss()
        self.loss_func = nn.CrossEntropyLoss(weight=weight.to(args.device))
        self.cos = torch.nn.CosineSimilarity(dim=-1)
        self.selected_clients = []
        self.ldr_train = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, collate_fn=call)
        self.glob_model = glob_model.to(args.device)
        self.old_models = old_models
        self.contrastive_alpha = 5
        self.temperature = 0.5
        self.verbose = verbose

    def train(self, model, args):
        model.train()
        # train and update
        optimizer = torch.optim.AdamW(model.parameters(), lr=self.args.lr)

        Predict_loss = 0
        Contrastive_loss = 0

        for iter in range(self.args.local_ep):
            epoch_loss_collector = []
            epoch_loss1_collector = []
            epoch_loss2_collector = []
            if args.model == 'bert':
                for i, (data, segment, mask, label) in enumerate(self.ldr_train):
                    data = data.to(args.device)
                    segment = segment.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    model.zero_grad()
                    output = model(data, segment, mask)
                    predictive_loss = self.loss_func(output, label)

                    #'representation': x.view(x.size(0), -1)


                    output_representation = output.view(output.size(0), -1)
                    global_out = self.glob_model(data, segment, mask)


                    pos_representation = global_out.view(global_out.size(0), -1)
                    posi = self.cos(output_representation, pos_representation)
                    logits = posi.reshape(-1, 1)

                    for previous_net in self.old_models:
                        neg_out = previous_net(data, segment, mask)

                        neg_representation = neg_out.view(neg_out.size(0), -1)
                        nega = self.cos(output_representation, neg_representation)
                        logits = torch.cat((logits, nega.reshape(-1, 1)), dim=1)

                    logits /= self.temperature
                    labels = torch.zeros(data.size(0)).to(self.args.device).long()


                    contrastive_loss = self.contrastive_alpha * self.loss_func1(logits, labels)

                    loss = predictive_loss + contrastive_loss
                    Predict_loss += predictive_loss.item()
                    Contrastive_loss += contrastive_loss.item()

                    loss.backward()
                    optimizer.step()

                    epoch_loss_collector.append(loss.item())
                    epoch_loss1_collector.append(predictive_loss.item())
                    epoch_loss2_collector.append(contrastive_loss.item())

            elif args.model == 'codebert':
                for i, (data, mask, label) in enumerate(self.ldr_train):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    output = model(data, mask)

                    predictive_loss = self.loss_func(output, label)

                    # 'representation': x.view(x.size(0), -1)

                    output_representation = output.view(output.size(0), -1)
                    global_out = self.glob_model(data, mask)

                    pos_representation = global_out.view(global_out.size(0), -1)
                    posi = self.cos(output_representation, pos_representation)
                    logits = posi.reshape(-1, 1)

                    for previous_net in self.old_models:
                        neg_out = previous_net(data, mask)

                        neg_representation = neg_out.view(neg_out.size(0), -1)
                        nega = self.cos(output_representation, neg_representation)
                        logits = torch.cat((logits, nega.reshape(-1, 1)), dim=1)

                    logits /= self.temperature
                    labels = torch.zeros(data.size(0)).to(self.args.device).long()

                    contrastive_loss = self.contrastive_alpha * self.loss_func1(logits, labels)

                    loss = predictive_loss + contrastive_loss
                    Predict_loss += predictive_loss.item()
                    Contrastive_loss += contrastive_loss.item()

                    loss.backward()
                    optimizer.step()

                    epoch_loss_collector.append(loss.item())
                    epoch_loss1_collector.append(predictive_loss.item())
                    epoch_loss2_collector.append(contrastive_loss.item())
            elif (args.model == 'gpt') or (args.model == 'opt'):
                for i, (data, mask, label) in enumerate(self.ldr_train):
                    data = data.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    output = model(data)['logits']

                    predictive_loss = self.loss_func(output, label)

                    # 'representation': x.view(x.size(0), -1)

                    output_representation = output.view(output.size(0), -1)
                    global_out = self.glob_model(data)['logits']

                    pos_representation = global_out.view(global_out.size(0), -1)
                    posi = self.cos(output_representation, pos_representation)
                    logits = posi.reshape(-1, 1)

                    for previous_net in self.old_models:
                        neg_out = previous_net(data)

                        neg_representation = neg_out.view(neg_out.size(0), -1)
                        nega = self.cos(output_representation, neg_representation)
                        logits = torch.cat((logits, nega.reshape(-1, 1)), dim=1)

                    logits /= self.temperature
                    labels = torch.zeros(data.size(0)).to(self.args.device).long()

                    contrastive_loss = self.contrastive_alpha * self.loss_func1(logits, labels)

                    loss = predictive_loss + contrastive_loss
                    Predict_loss += predictive_loss.item()
                    Contrastive_loss += contrastive_loss.item()

                    loss.backward()
                    optimizer.step()

                    epoch_loss_collector.append(loss.item())
                    epoch_loss1_collector.append(predictive_loss.item())
                    epoch_loss2_collector.append(contrastive_loss.item())

            elif (args.model == 't5') or (args.model =='codet5'):
                for i, (data, mask, label) in enumerate(self.ldr_train):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    output = model(data, mask, decoder_input_ids=data)

                    predictive_loss = self.loss_func(output, label)

                    # 'representation': x.view(x.size(0), -1)

                    output_representation = output.view(output.size(0), -1)
                    global_out = self.glob_model(data, mask)

                    pos_representation = global_out.view(global_out.size(0), -1)
                    posi = self.cos(output_representation, pos_representation)
                    logits = posi.reshape(-1, 1)

                    for previous_net in self.old_models:
                        neg_out = previous_net(data, mask)

                        neg_representation = neg_out.view(neg_out.size(0), -1)
                        nega = self.cos(output_representation, neg_representation)
                        logits = torch.cat((logits, nega.reshape(-1, 1)), dim=1)

                    logits /= self.temperature
                    labels = torch.zeros(data.size(0)).to(self.args.device).long()

                    contrastive_loss = self.contrastive_alpha * self.loss_func1(logits, labels)

                    loss = predictive_loss + contrastive_loss
                    Predict_loss += predictive_loss.item()
                    Contrastive_loss += contrastive_loss.item()

                    loss.backward()
                    optimizer.step()

                    epoch_loss_collector.append(loss.item())
                    epoch_loss1_collector.append(predictive_loss.item())
                    epoch_loss2_collector.append(contrastive_loss.item())

        return model.state_dict()