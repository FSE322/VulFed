import numpy as np
from itertools import product

from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import fcluster
from copy import deepcopy
from tqdm import *
from Algorithm.method import *
from utils import *
import torch
from torch.utils.data import ConcatDataset, DataLoader
from tqdm import tqdm



def ClusterSampling_bert(net_glob, dataset_train, dataset_test, dict_users, args, call, label_dict=None):

    net_glob.to('cpu')

    n_samples = np.array([len(dict_users[idx]) for idx in dict_users.keys()])
    weights = n_samples / np.sum(n_samples)
    n_sampled = max(int(args.frac * args.num_users), 1)
    gradients = get_gradients('', net_glob, [net_glob] * len(dict_users))

    net_glob.train()

    # training
    acc, pre, rec, f1 = [], [], [], []
    weight = calc_weight(ConcatDataset([dataset_train, dataset_test]), args.num_classes)
    #weight:data weight \weights:clusamp weight

    for iter in range(args.epochs):
        print('*' * 80)
        print('Round {:3d}'.format(iter))

        previous_global_model = copy.deepcopy(net_glob)
        clients_models = []
        sampled_clients_for_grad = []

        if iter == 0:
            sim_matrix = get_matrix_similarity_from_grads(
                gradients, distance_type='L1'
            )
        linkage_matrix = linkage(sim_matrix, "ward")
        distri_clusters = get_clusters_with_alg2(
            linkage_matrix, n_sampled, weights
        )

        w_locals = []
        lens = []
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = sample_clients(distri_clusters)
        for idx in tqdm(idxs_users, desc='Training...'):
            local = LocalUpdate_ClusterSampling_bert(args=args, call=call, weight=weight, dataset=dataset_train,
                                            idxs=dict_users[idx])
            local_model = local.train(model=copy.deepcopy(net_glob).to(args.device), args=args)
            local_model.to('cpu')

            w_locals.append(copy.deepcopy(local_model.state_dict()))
            lens.append(len(dict_users[idx]))

            clients_models.append(copy.deepcopy(local_model))
            sampled_clients_for_grad.append(idx)

            del local_model

        # update global weights

        w_glob = Aggregation(w_locals, lens)

        # copy weight to net_glob
        net_glob.load_state_dict(w_glob)

        gradients_i = get_gradients(
            '', previous_global_model, clients_models
        )
        for idx, gradient in zip(sampled_clients_for_grad, gradients_i):
            gradients[idx] = gradient
        sim_matrix = get_matrix_similarity_from_grads_new(
            gradients, distance_type='L1', idx=idxs_users, metric_matrix=sim_matrix
        )

        net_glob.to(args.device)

        acc_one, pre_one, rec_one, f1_one, metric_one = test_bert(net_glob, dataset_test, args, call)
        acc.append(acc_one)
        pre.append(pre_one)
        rec.append(rec_one)
        f1.append(f1_one)
        print("\nacc:" + str(acc_one))
        print("precision:" + str(pre_one))
        print("recall:" + str(rec_one))
        print("f1:" + str(f1_one))

        net_glob.to('cpu')
        del clients_models

        if args.cwecase == 0:
            print(metric_one)
        else:
            for i in range(len(metric_one)):
                acc_i = metric_one[i][i] / sum(metric_one[i])
                if i == 0:
                    print("FP：{}".format(1-acc_i))
                else:
                    cweclass = [key for key, val in label_dict.items() if val == (i-1)]
                    print("{}TP：{}".format(cweclass[0], acc_i))


    save_result(acc, 'test_acc', args)
    save_result(pre, 'test_pre', args)
    save_result(rec, 'test_rec', args)
    save_result(f1, 'test_f1', args)



class LocalUpdate_ClusterSampling_bert(object):
    def __init__(self, args, call, weight, dataset=None, idxs=None):
        self.args = args
        self.loss_func = torch.nn.CrossEntropyLoss(weight=weight.to(args.device))
        self.train_loader = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, collate_fn=call)

    def train(self, model, args):
        model.train()

        optimizer = torch.optim.AdamW(model.parameters(), lr=self.args.lr)

        for iter in range(self.args.local_ep):

            if args.model == 'bert':
                for i, (data, segment, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    segment = segment.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, segment, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif args.model == 'codebert':
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 'gpt') or (args.model == 'opt'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data)
                    loss = self.loss_func(outputs.logits, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 't5') or (args.model =='codet5'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask, decoder_input_ids=data)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()

        return model



def get_clusters_with_alg1(n_sampled: int, weights: np.array):
    "Algorithm 1"

    epsilon = int(10 ** 10)
    # associate each client to a cluster
    augmented_weights = np.array([w * n_sampled * epsilon for w in weights])
    ordered_client_idx = np.flip(np.argsort(augmented_weights))

    n_clients = len(weights)
    distri_clusters = np.zeros((n_sampled, n_clients)).astype(int)

    k = 0
    for client_idx in ordered_client_idx:

        while augmented_weights[client_idx] > 0:

            sum_proba_in_k = np.sum(distri_clusters[k])

            u_i = min(epsilon - sum_proba_in_k, augmented_weights[client_idx])

            distri_clusters[k, client_idx] = u_i
            augmented_weights[client_idx] += -u_i

            sum_proba_in_k = np.sum(distri_clusters[k])
            if sum_proba_in_k == 1 * epsilon:
                k += 1

    distri_clusters = distri_clusters.astype(float)
    for l in range(n_sampled):
        distri_clusters[l] /= np.sum(distri_clusters[l])

    return distri_clusters


def get_similarity(grad_1, grad_2, distance_type="L1"):

    if distance_type == "L1":

        norm = 0
        for g_1, g_2 in zip(grad_1, grad_2):
            norm += np.sum(np.abs(g_1 - g_2))
        return norm

    elif distance_type == "L2":
        norm = 0
        for g_1, g_2 in zip(grad_1, grad_2):
            norm += np.sum((g_1 - g_2) ** 2)
        return norm

    elif distance_type == "cosine":
        norm, norm_1, norm_2 = 0, 0, 0
        for i in range(len(grad_1)):
            norm += np.sum(grad_1[i] * grad_2[i])
            norm_1 += np.sum(grad_1[i] ** 2)
            norm_2 += np.sum(grad_2[i] ** 2)

        if norm_1 == 0.0 or norm_2 == 0.0:
            return 0.0
        else:
            norm /= np.sqrt(norm_1 * norm_2)

            return np.arccos(norm)

def get_gradients(sampling, global_m, local_models):
    """return the `representative gradient` formed by the difference between
    the local work and the sent global model"""

    local_model_params = []
    for model in local_models:
        local_model_params += [
            [tens.detach().numpy() for tens in list(model.parameters())]
        ]

    global_model_params = [
        tens.detach().numpy() for tens in list(global_m.parameters())
    ]

    local_model_grads = []
    for local_params in local_model_params:
        local_model_grads += [
            [
                local_weights - global_weights
                for local_weights, global_weights in zip(
                    local_params, global_model_params
                )
            ]
        ]

    return local_model_grads


def get_matrix_similarity_from_grads(local_model_grads, distance_type):
    """return the similarity matrix where the distance chosen to
    compare two clients is set with `distance_type`"""

    n_clients = len(local_model_grads)

    metric_matrix = np.zeros((n_clients, n_clients))

    tqdmbar = tqdm(product(range(n_clients), range(n_clients)))
    for i, j in tqdmbar:

        metric_matrix[i, j] = get_similarity(
            local_model_grads[i], local_model_grads[j], distance_type
        )

    return metric_matrix


def get_matrix_similarity_from_grads_new(local_model_grads, distance_type, idx, metric_matrix):
    """return the similarity matrix where the distance chosen to
    compare two clients is set with `distance_type`"""

    for i in idx:
        for j in idx:
            if i == j:
                continue
        metric_matrix[i, j] = get_similarity(
            local_model_grads[i], local_model_grads[j], distance_type
        )

    return metric_matrix


def get_matrix_similarity(global_m, local_models, distance_type):

    n_clients = len(local_models)

    local_model_grads = get_gradients(global_m, local_models)

    metric_matrix = np.zeros((n_clients, n_clients))
    for i, j in product(range(n_clients), range(n_clients)):

        metric_matrix[i, j] = get_similarity(
            local_model_grads[i], local_model_grads[j], distance_type
        )

    return metric_matrix


def get_clusters_with_alg2(
    linkage_matrix: np.array, n_sampled: int, weights: np.array
):
    """Algorithm 2"""
    epsilon = int(10 ** 10)

    # associate each client to a cluster
    link_matrix_p = deepcopy(linkage_matrix)
    augmented_weights = deepcopy(weights)

    for i in range(len(link_matrix_p)):
        idx_1, idx_2 = int(link_matrix_p[i, 0]), int(link_matrix_p[i, 1])

        new_weight = np.array(
            [augmented_weights[idx_1] + augmented_weights[idx_2]]
        )
        augmented_weights = np.concatenate((augmented_weights, new_weight))
        link_matrix_p[i, 2] = int(new_weight * epsilon)

    clusters = fcluster(
        link_matrix_p, int(epsilon / n_sampled), criterion="distance"
    )

    n_clients, n_clusters = len(clusters), len(set(clusters))

    # Associate each cluster to its number of clients in the cluster
    pop_clusters = np.zeros((n_clusters, 2)).astype(int)
    for i in range(n_clusters):
        pop_clusters[i, 0] = i + 1
        for client in np.where(clusters == i + 1)[0]:
            pop_clusters[i, 1] += int(weights[client] * epsilon * n_sampled)

    pop_clusters = pop_clusters[pop_clusters[:, 1].argsort()]

    distri_clusters = np.zeros((n_sampled, n_clients)).astype(int)

    # n_sampled biggest clusters that will remain unchanged
    kept_clusters = pop_clusters[n_clusters - n_sampled :, 0]

    for idx, cluster in enumerate(kept_clusters):
        for client in np.where(clusters == cluster)[0]:
            distri_clusters[idx, client] = int(
                weights[client] * n_sampled * epsilon
            )

    k = 0
    for j in pop_clusters[: n_clusters - n_sampled, 0]:

        clients_in_j = np.where(clusters == j)[0]
        np.random.shuffle(clients_in_j)

        for client in clients_in_j:

            weight_client = int(weights[client] * epsilon * n_sampled)

            while weight_client > 0:

                sum_proba_in_k = np.sum(distri_clusters[k])

                u_i = min(epsilon - sum_proba_in_k, weight_client)

                distri_clusters[k, client] = u_i
                weight_client += -u_i

                sum_proba_in_k = np.sum(distri_clusters[k])
                if sum_proba_in_k == 1 * epsilon:
                    k += 1

    distri_clusters = distri_clusters.astype(float)
    for l in range(n_sampled):
        distri_clusters[l] /= np.sum(distri_clusters[l])

    return distri_clusters


from numpy.random import choice


def sample_clients(distri_clusters):

    n_clients = len(distri_clusters[0])
    n_sampled = len(distri_clusters)

    sampled_clients = np.zeros(len(distri_clusters), dtype=int)

    for k in range(n_sampled):
        sampled_clients[k] = int(choice(n_clients, 1, p=distri_clusters[k]))

    return sampled_clients
