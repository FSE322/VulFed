import copy
import numpy as np
from Algorithm.method import *
from utils import *
import torch
from torch.utils.data import ConcatDataset, DataLoader
from tqdm import tqdm
from torch import nn
import torch.nn.functional as F
import numpy as np



def FedCross_bert(net_glob, dataset_train, dataset_test, dict_users, args, call, label_dict=None):

    #constant
    first_stage_bound = 0
    fedcross_alpha = 0.9
    fedcross_collaberative_model_select_strategy = 0


    net_glob.train()

    # training
    acc, pre, rec, f1 = [], [], [], []
    w_locals, sim_arr = [], []
    weight = calc_weight(ConcatDataset([dataset_train, dataset_test]), args.num_classes)

    m = max(int(args.frac * args.num_users), 1)
    for i in range(m):
        w_locals.append(copy.deepcopy(net_glob.state_dict()))

    for iter in range(args.epochs):

        print('*' * 80)
        print('Round {:3d}'.format(iter))
        m = max(int(args.frac * args.num_users), 1)
        idxs_users = np.random.choice(range(args.num_users), m, replace=False)

        for i, idx in tqdm(enumerate(idxs_users), desc='Training...'):
            net_glob.load_state_dict(w_locals[i])
            local = LocalUpdate_FedCross_bert(args=args, call=call, weight=weight, dataset=dataset_train, idxs=dict_users[idx])

            w = local.train(net_glob, args)
            w_locals[i] = copy.deepcopy(w)

        # update global weights

        w_glob = Aggregation(w_locals, None)

        # copy weight to net_glob
        net_glob.load_state_dict(w_glob)


        acc_one, pre_one, rec_one, f1_one, metric_one = test_bert(net_glob, dataset_test, args, call)
        acc.append(acc_one)
        pre.append(pre_one)
        rec.append(rec_one)
        f1.append(f1_one)
        print("\nacc:"+str(acc_one))
        print("precision:" + str(pre_one))
        print("recall:" + str(rec_one))
        print("f1:" + str(f1_one))

        sim_tab, sim_value = sim(args, w_locals)
        sim_arr.append(sim_value)
        if iter >= first_stage_bound:
            w_locals = cross_aggregation(fedcross_alpha, fedcross_collaberative_model_select_strategy, iter, sim_tab, w_locals, m)  # Multi-Model Cross-Aggregation
        else:
            for i in range(len(w_locals)):
                w_locals[i] = copy.deepcopy(w_glob)

        if args.cwecase == 0:
            print(metric_one)
        else:
            for i in range(len(metric_one)):
                acc_i = metric_one[i][i] / sum(metric_one[i])
                if i == 0:
                    print("FP：{}".format(1-acc_i))
                else:
                    cweclass = [key for key, val in label_dict.items() if val == (i-1)]
                    print("{}TP：{}".format(cweclass[0], acc_i))


    save_result(acc, 'test_acc', args)
    save_result(pre, 'test_pre', args)
    save_result(rec, 'test_rec', args)
    save_result(f1, 'test_f1', args)


class LocalUpdate_FedCross_bert(object):
    def __init__(self, args, call, weight, dataset=None, idxs=None):
        self.args = args
        self.loss_func = torch.nn.CrossEntropyLoss(weight=weight.to(args.device))
        self.train_loader = DataLoader(DatasetSplit(dataset, idxs), batch_size=self.args.local_bs, shuffle=True, collate_fn=call)

    def train(self, model, args):
        model.train()

        optimizer = torch.optim.AdamW(model.parameters(), lr=self.args.lr)

        for iter in range(self.args.local_ep):

            if args.model == 'bert':
                for i, (data, segment, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    segment = segment.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, segment, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif args.model == 'codebert':
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 'gpt') or (args.model == 'opt'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data)
                    loss = self.loss_func(outputs.logits, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()
            elif (args.model == 't5') or (args.model =='codet5'):
                for i, (data, mask, label) in enumerate(self.train_loader):
                    data = data.to(args.device)
                    mask = mask.to(args.device)
                    label = label.to(args.device)

                    optimizer.zero_grad()
                    outputs = model(data, mask, decoder_input_ids=data)
                    loss = self.loss_func(outputs, label)
                    loss.backward()
                    # pred = torch.max(outputs.data, dim=1)[1]
                    # correct += (pred == label).sum()
                    optimizer.step()

        return model.state_dict()


def cross_aggregation(fedcross_alpha, fedcross_collaberative_model_select_strategy, iter, sim_tab, w_locals, m):
    w_locals_new = copy.deepcopy(w_locals)

    crosslist = []

    for j in range(m):
        maxtag = 0
        submax = 1
        mintag = (j + 1) % m
        for p in range(m):
            if sim_tab[j][p] > sim_tab[j][maxtag]:
                submax = maxtag
                maxtag = p
            elif sim_tab[j][p] > sim_tab[j][submax]:
                submax = p

            if sim_tab[j][p] < sim_tab[j][mintag] and p != j:
                mintag = p

        rlist = []
        offset = iter % (m - 1) + 1
        sub_list = []
        alpha = fedcross_alpha
        select_strategy = fedcross_collaberative_model_select_strategy
        for k in range(m):
            if k == j:
                rlist.append(alpha)
                sub_list.append(copy.deepcopy(w_locals[j]))

            if select_strategy == 0:
                if (j + offset) % m == k:
                    rlist.append(1.0 - alpha)
                    sub_list.append(copy.deepcopy(w_locals[k]))
            elif select_strategy == 1:
                if mintag == k:
                    rlist.append(1.0 - alpha)
                    sub_list.append(copy.deepcopy(w_locals[mintag]))
            elif select_strategy == 2:
                if maxtag == k:
                    rlist.append(1.0 - alpha)
                    sub_list.append(copy.deepcopy(w_locals[maxtag]))
            # elif submax == k:
            #     rlist.append(0.05)
            #     sub_list.append(copy.deepcopy(w_locals[k]))
            # if mintag == k:
            #     rlist.append(1.0 - alpha)
            #     sub_list.append(copy.deepcopy(w_locals[mintag]))
            # if (j + offset) % turntable == k:
            #     rlist.append(0.01)
            #     sub_list.append(copy.deepcopy(w_locals[k]))
            # else:
            #     rlist.append(0.01)
        w_cc = Aggregation(sub_list, rlist)
        crosslist.append(w_cc)

    for k in range(m):
        w_locals_new[k] = crosslist[k]

    return w_locals_new

def sim(args, net_glob_arr):
    model_num = int(args.num_users * args.frac)
    sim_tab = [[0 for _ in range(model_num)] for _ in range(model_num)]
    minsum = 10
    subminsum = 10
    sum_sim = 0.0
    for k in range(model_num):
        sim_arr = []
        idx = 0
        # sim_sum = 0.0
        for j in range(k):
            sim = 0.0
            s = 0.0
            dict_a = torch.Tensor(0)
            dict_b = torch.Tensor(0)
            cnt = 0
            for p in net_glob_arr[k].keys():
                a = net_glob_arr[k][p]
                b = net_glob_arr[j][p]
                a = a.view(-1)
                b = b.view(-1)

                if cnt == 0:
                    dict_a = a
                    dict_b = b
                else:
                    dict_a = torch.cat((dict_a, a), dim=0)
                    dict_b = torch.cat((dict_b, b), dim=0)

                if cnt % 5 == 0:
                    sub_a = a
                    sub_b = b
                else:
                    sub_a = torch.cat((sub_a, a), dim=0)
                    sub_b = torch.cat((sub_b, b), dim=0)
                    # if not a.equal(b):
                    #     sub_a = torch.cat((sub_a, a), dim=0)
                    #     sub_b = torch.cat((sub_b, b), dim=0)

                if cnt % 5 == 4:
                    s += F.cosine_similarity(sub_a, sub_b, dim=0)
                cnt += 1
            # print(sim)
            s += F.cosine_similarity(sub_a, sub_b, dim=0)
            sim = F.cosine_similarity(dict_a, dict_b, dim=0)
            # print (sim)
            sim_arr.append(sim)
            sim_tab[k][j] = sim
            sim_tab[j][k] = sim
            sum_sim += copy.deepcopy(s)
    l = int(len(net_glob_arr[0].keys()) / 5) + 1.0
    sum_sim /= (45.0 * l)
    return sim_tab, sum_sim