import torch
import copy
import numpy as np
from sklearn.metrics import *
import datetime
import os
from torch.utils.data import DataLoader, Dataset



class DatasetSplit(Dataset):
    def __init__(self, dataset, idxs):
        self.dataset = dataset
        self.idxs = list(idxs)

    def __len__(self):
        return len(self.idxs)

    def __getitem__(self, item):
        image, label = self.dataset[self.idxs[item]]
        return image, label

def Aggregation(w, lens):
    w_avg = None
    if lens == None:
        total_count = len(w)
        lens = []
        for i in range(len(w)):
            lens.append(1.0)
    else:
        total_count = sum(lens)

    for i in range(0, len(w)):
        if i == 0:
            w_avg = copy.deepcopy(w[0])
            for k in w_avg.keys():
                w_avg[k] = w[i][k] * lens[i]
        else:
            for k in w_avg.keys():
                w_avg[k] += w[i][k] * lens[i]

    for k in w_avg.keys():
        w_avg[k] = torch.div(w_avg[k], total_count)

    return w_avg

def test_bert(model, dataset, args, call):
    print("now testing")
    test_loader = DataLoader(dataset, batch_size=args.test_bs, shuffle=True, collate_fn=call)
    model.eval()
    martix_total = np.array([[0,0],[0,0]])
    predict_total = np.array([], dtype=int)
    label_total = np.array([], dtype=int)

    if args.model == 'bert':
        for i, (data, segment, mask, label) in enumerate(test_loader):
            with torch.no_grad():
                data = data.to(args.device)
                segment = segment.to(args.device)
                mask = mask.to(args.device)
                label = label.to(args.device)

                #batch_size = data.shape[0]
                outputs = model(data, segment, mask)
                pred = torch.max(outputs.data, dim=1)[1]

                matrix = confusion_matrix(label.cpu(), pred.cpu(), labels=[1, 0])
                martix_total += matrix

                label = label.data.cpu().numpy()
                predict = pred.cpu().numpy()
                label_total = np.append(label_total, label)
                predict_total = np.append(predict_total, predict)
    elif args.model == 'codebert':
        for i, (data, mask, label) in enumerate(test_loader):
            with torch.no_grad():
                data = data.to(args.device)
                mask = mask.to(args.device)
                label = label.to(args.device)

                # batch_size = data.shape[0]
                outputs = model(data, mask)
                pred = torch.max(outputs.data, dim=1)[1]

                matrix = confusion_matrix(label.cpu(), pred.cpu(), labels=[1, 0])
                martix_total += matrix

                label = label.data.cpu().numpy()
                predict = pred.cpu().numpy()
                label_total = np.append(label_total, label)
                predict_total = np.append(predict_total, predict)

            # total_score.update(matrix)
            # summary_loss.update(loss.detach().item(), batch_size)
    elif (args.model == 'gpt') or (args.model == 'opt'):
        for i, (data, mask, label) in enumerate(test_loader):
            with torch.no_grad():
                data = data.to(args.device)
                mask = mask.to(args.device)
                label = label.to(args.device)

                outputs = model(data)
                pred = torch.max(outputs.logits, dim=1)[1]

                matrix = confusion_matrix(label.cpu(), pred.cpu(), labels=[1, 0])
                martix_total += matrix

                label = label.data.cpu().numpy()
                predict = pred.cpu().numpy()
                label_total = np.append(label_total, label)
                predict_total = np.append(predict_total, predict)
    elif (args.model == 't5') or (args.model == 'codet5'):
        for i, (data, mask, label) in enumerate(test_loader):
            with torch.no_grad():
                data = data.to(args.device)
                mask = mask.to(args.device)
                label = label.to(args.device)

                # batch_size = data.shape[0]
                outputs = model(data, mask, decoder_input_ids=data)
                pred = torch.max(outputs.data, dim=1)[1]

                matrix = confusion_matrix(label.cpu(), pred.cpu(), labels=[1, 0])
                martix_total += matrix

                label = label.data.cpu().numpy()
                predict = pred.cpu().numpy()
                label_total = np.append(label_total, label)
                predict_total = np.append(predict_total, predict)

            # total_score.update(matrix)
            # summary_loss.update(loss.detach().item(), batch_size)



    if args.num_classes == 2:
        pre = precision_score(label_total, predict_total)
        rec = recall_score(label_total, predict_total)
        f1 = f1_score(label_total, predict_total)
        acc = accuracy_score(label_total, predict_total)
        confusion = confusion_matrix(label_total, predict_total)
    else:
        pre = precision_score(label_total, predict_total, average='macro')
        rec = recall_score(label_total, predict_total, average='macro')
        f1 = f1_score(label_total, predict_total, average='macro')
        acc = accuracy_score(label_total, predict_total)
        confusion = confusion_matrix(label_total, predict_total)
    return acc, pre, rec, f1, confusion

def save_result(data, ylabel, args):

    path = './output'
    file = '{}_{}_{}_{}_{}.txt'.format(args.model, args.algorithm, args.peft, args.dataset, ylabel)

    if not os.path.exists(path):
        os.makedirs(path)

    with open(os.path.join(path, file), 'a') as f:
        for i in range(len(data)):
            f.write(str(i+1))
            f.write(' ')
            f.write(str(data[i]))
            f.write('\n')
    print('save finished')
    f.close()