import json
from datasets import *
from utils import *
from dataprocess.builddataset import *
from collections import Counter

def diversevul():
    file = open('data/diversevul_20230702.json', 'r')
    data = []
    for line in file.readlines():
        dic = json.loads(line)
        data.append(dic)

    for i in data:
        if not i['cwe']:
            i['cwe'].append('CWE-None')
        elif len(i['cwe']) > 1:
            i['cwe'] = i['cwe'][:1]

    data1, data0 = [], []
    for i in data:
        if i['target'] == 1:
            data1.append(i)
        elif len(data0) < 300000:
            data0.append(i)

    key_occ = {}
    for d in data1:
        if 'cwe' in d:
            value = d['cwe'][0]
            if value in key_occ:
                key_occ[value] += 1
            else:
                key_occ[value] = 1

    filterdata1 = [d for d in data1 if 'cwe' in d and key_occ[d['cwe'][0]] >= 100]
    labels = [d['cwe'][0] for d in filterdata1]
    unique_labels = list(set(labels))
    label_dict = {label: i for i, label in enumerate(unique_labels)}

    diversevul_dataset = diversevul_source(filterdata1, data0, label_dict)

    train, test = averlist_traintest(diversevul_dataset, 0.2)
    return train, test, label_dict


def devign(mode):
    data = load_dataset('data/devign')
    train = dataset_devign(data['train'], mode)
    test = dataset_devign(data['test'], mode)
    return train, test

def codegadget():
    cgddataset = dataset_cgd('data/cwe119_cgd.txt', 100)
    train, test = averlist_traintest(cgddataset, 0.2)
    return train, test

def syvc():
    sysource = load_dataset('data/syvc')
    sydataset = dataset_sy(sysource)
    train, test = averlist_traintest(sydataset, 0.2)
    return train, test
