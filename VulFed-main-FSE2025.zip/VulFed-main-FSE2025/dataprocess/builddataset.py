from torch.utils.data import Dataset
from dataprocess.readcodegadget import *

class diversevul_source(Dataset):
    def __init__(self, vul, safe, label_dict):
        self.vuldata = []
        self.safedata = []
        self.vullabellist = []
        self.safelabellist = []

        for i in vul:
            self.vuldata.append(i['func'])
            self.vullabellist.append(label_dict[i['cwe'][0]]+1)
        for i in safe:
            self.safedata.append(i['func'])
            self.safelabellist.append(0)

        self.codedata = self.vuldata + self.safedata
        self.labellist = self.vullabellist + self.safelabellist

    def __len__(self):
        return len(self.codedata)

    def __getitem__(self, item):
        return self.codedata[item], self.labellist[item]



class dataset_cgd(Dataset):
    def __init__(self, filename: str, vector_length: int):
        self.infos = []
        self.cgds = []
        self.labels = []
        self.vectorizer = GadgetVectorizer_simple(vector_length)
        with open(filename, "r", encoding="utf8") as file:
            current_case = []
            for line in file:
                stripped = line.strip()
                if not stripped:
                    continue
                if "-" * 33 in line and current_case:
                    self.infos.append(current_case[0])
                    gadget = clean_gadget(current_case[1:-1])
                    self.cgds.append(gadget)
                    self.labels.append(int(current_case[-1]))
                    self.vectorizer.add_gadget(gadget)
                    current_case = []
                else:
                    current_case.append(stripped)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        vectors = self.vectorizer.vectorize(self.cgds[index])
        label = self.labels[index]
        return vectors, label


class dataset_devign(Dataset):
    def __init__(self, source_dict, mode='raw'):
        if mode == 'raw':
            self.codesource = source_dict['func']
        elif mode == 'clean':
            self.codesource = source_dict['func_clean']
        elif mode == 'normalized':
            self.codesource = source_dict['normalized_func']

        self.labels = []
        for i in source_dict:
            if i['target'] == True:
                self.labels.append(1)
            else:
                self.labels.append(0)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        return self.codesource[index], self.labels[index]



class dataset_sy(Dataset):
    def __init__(self, source):
        self.source = source

    def __len__(self):
        return len(self.source)

    def __getitem__(self, index):
        return self.source['data'][index], self.source['label'][index]