import argparse

def args_parser():
    parser = argparse.ArgumentParser()

    parser.add_argument('--epochs', type=int, default=50, help="rounds of training")
    parser.add_argument('--num_users', type=int, default=10, help="number of users: K")
    parser.add_argument('--frac', type=float, default=0.5, help="the fraction of clients: C")
    parser.add_argument('--num_classes', type=int, default=2, help="number of classes")
    parser.add_argument('--local_ep', type=int, default=1, help="the number of local epochs: E")
    parser.add_argument('--local_bs', type=int, default=16, help="local batch size: B")
    parser.add_argument('--test_bs', type=int, default=32, help="test batch size")
    parser.add_argument('--optimizer', type=str, default='adam', help='the optimizer')
    parser.add_argument('--lr', type=float, default=0.00001, help="learning rate")
    parser.add_argument('--seed', type=int, default=1, help='random seed (default: 1)')
    parser.add_argument('--gpu', type=int, default=0, help="GPU ID, -1 for CPU")

    parser.add_argument('--dataset', type=str, default='codegadget', help="diversevul;codegadget;devign_normalized;syvc")
    parser.add_argument('--datapath', type=str, default='/home/zph/model')
    parser.add_argument('--cwecase', type=int, default=0, help="0-nocase,1-case")
    parser.add_argument('--lingual', type=int, default=0, help="0-singlelingual,1-multilingual")
    parser.add_argument('--noniidcase', type=int, default=0, help="0-iid,1-noniid")
    parser.add_argument("--algorithm", type=str, default="FedAvg", help="FedAvg;FedProx;FedCross;CluSamp;Moon;FedMut")
    parser.add_argument('--model', type=str, default='bert', help='bert;codebert;gpt;opt;t5;codet5')
    parser.add_argument('--peft', type=str, default='none', help='none;ptv1;ptv2;lora;loha;ia3')
    parser.add_argument('--single', type=int, default=0, help="0-nosingle,1-single,2-publicglobal")

    args = parser.parse_args()
    return args
