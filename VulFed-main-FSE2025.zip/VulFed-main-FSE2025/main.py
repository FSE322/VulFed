import torch
import numpy
from options import args_parser
from dataprocess.builddataset import *
from utils import *
from dataprocess.readdata import *

from model.bert import *
from model.codebert import *
from model.gpt import *
from model.t5 import *
from model.bertforpeft import *

from transformers import BertModel, BertConfig, BertTokenizer, AutoConfig, AutoModel, AutoTokenizer, GPT2Model, GPT2ForSequenceClassification, CodeGenForCausalLM, OPTForSequenceClassification, BertForSequenceClassification

from Algorithm.FedAvg import *
from Algorithm.FedProx import *
from Algorithm.FedCross import *
from Algorithm.ClusterSampling import *
from Algorithm.Moon import *
from Algorithm.FedMut import *

import copy
import peft


if __name__ == '__main__':
    args = args_parser()
    args.device = torch.device('cuda:{}'.format(args.gpu) if torch.cuda.is_available() and args.gpu != -1 else 'cpu')

    print("---------start-----------")
    print("model:{}".format(args.model))
    print("algorithm:{}".format(args.algorithm))
    print("dataset:{}".format(args.dataset))
    print("peft:{}".format(args.peft))
    print("-------------------------")



    #choose dataset
    if args.dataset == 'diversevul':
        train, test, label_dict = diversevul()
        if args.single == 1:
            train = getsubset(train, 0.1)
    elif args.dataset == 'codegadget':
        train, test = codegadget()
    elif args.dataset == 'syvc':
        train, test = syvc()
    elif args.dataset == 'devign_normalized':
        train, test = devign('normalized')


    print("data process succeed")

    #allocate dict sample
    if args.noniidcase == 0:
        dict_users = iid(train, args.num_users)
    elif args.noniidcase == 1:
        dict_users = noniid(train, args.num_users, args.num_classes, 0.5)
    for i in range(len(dict_users)):
        print(len(dict_users[i]))


    #choose model
    if args.model == 'bert':
        targetmodel = args.datapath + '/bert-base-uncased'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        call = bert_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel)
        encode_model = AutoModel.from_pretrained((targetmodel+'/pytorch_model.bin'),
                                                 config=modelconfig)
        net_glob = bert_MultiClass(encode_model, modelconfig, args.num_classes).to(args.device)
    elif args.model == 'codebert':
        targetmodel = args.datapath + '/codebert-base'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        call = codebert_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel)
        encode_model = AutoModel.from_pretrained((targetmodel+'/pytorch_model.bin'),
                                                 config=modelconfig)
        net_glob = codebert_MultiClass(encode_model, modelconfig, args.num_classes).to(args.device)
    elif args.model == 'gpt':
        targetmodel = args.datapath + '/gpt2'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        tokenizer.pad_token = tokenizer.eos_token
        call = gpt2_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel, num_labels=args.num_classes)
        net_glob = GPT2ForSequenceClassification.from_pretrained(targetmodel, config=modelconfig).to(args.device)
        net_glob.config.pad_token_id = net_glob.config.eos_token_id
    elif args.model == 'opt':
        targetmodel = args.datapath + '/opt'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        tokenizer.pad_token = tokenizer.eos_token
        call = gpt2_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel, num_labels=args.num_classes)
        net_glob = OPTForSequenceClassification.from_pretrained(targetmodel, config=modelconfig).to(args.device)
        net_glob.config.pad_token_id = net_glob.config.eos_token_id
    elif args.model == "t5":
        targetmodel = args.datapath + '/t5small'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        call = gpt2_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel)
        encode_model = AutoModel.from_pretrained((targetmodel+'/pytorch_model.bin'),
                                                 config=modelconfig)
        net_glob = t5_MultiClass(encode_model, modelconfig, args.num_classes).to(args.device)

    elif args.model == 'codet5':
        targetmodel = args.datapath + '/codet5small'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        call = gpt2_BatchTextCall(tokenizer, max_len=512)
        modelconfig = AutoConfig.from_pretrained(targetmodel)
        encode_model = AutoModel.from_pretrained((targetmodel+'/pytorch_model.bin'),
                                                 config=modelconfig)
        net_glob = t5_MultiClass(encode_model, modelconfig, args.num_classes).to(args.device)


    print("model initilized succeed")


    #choosePeft
    if args.peft == 'none':
        model = copy.deepcopy(net_glob).to(args.device)
    else:
        targetmodel = args.datapath + '/codebert-base'
        tokenizer = AutoTokenizer.from_pretrained(targetmodel)
        call = codebert_BatchTextCall(tokenizer, max_len=492)
        modelconfig = AutoConfig.from_pretrained(targetmodel)
        model = BertForSequenceClassification.from_pretrained(targetmodel)

        if args.peft == 'ptv1':
            peft_config = peft.PromptEncoderConfig(
                peft_type="PREFIX_TUNING",
                task_type="SEQ_CLS",
                num_virtual_tokens=20,
                token_dim=768,
                num_transformer_submodules=1,
                num_attention_heads=12,
                num_layers=12,
                encoder_hidden_size=768
            )

        if args.peft == 'ptv2':
            peft_config = peft.PrefixTuningConfig(
                peft_type="PREFIX_TUNING",
                task_type="SEQ_CLS",
                num_virtual_tokens=20,
                token_dim=768,
                num_transformer_submodules=1,
                num_attention_heads=12,
                num_layers=12,
                encoder_hidden_size=768,
                prefix_projection=True
            )

        if args.peft == 'lora':
            peft_config = peft.LoraConfig(
                peft_type="LORA",
                task_type="SEQ_CLS",
                inference_mode=False,
                r=8,
                lora_alpha=16,
                lora_dropout=0.1,
                fan_in_fan_out=False,
                bias='lora_only'
            )

        if args.peft == 'loha':
            peft_config = peft.LoHaConfig(
                peft_type="LORA",
                task_type="SEQ_CLS",
                inference_mode=False,
                r=8,
                target_modules=['key', 'value', 'output.dense']
            )

        if args.peft == 'ia3':
            peft_config = peft.IA3Config(
                peft_type="IA3",
                task_type="SEQ_CLS",
                inference_mode=False,
                target_modules=['key', 'value', 'output.dense'],
                feedforward_modules=['output.dense']
            )

        model = peft.get_peft_model(model, peft_config)
        model.print_trainable_parameters()
        model = Bert_for_Peft(model)
        model.to(args.device)



    #choose algorithm
    if args.cwecase == 0:
        if args.algorithm == 'FedAvg':
            FedAvg_bert(model, train, test, dict_users, args, call)
        if args.algorithm == 'FedProx':
            FedProx_bert(model, train, test, dict_users, args, call)
        if args.algorithm == 'FedCross':
            FedCross_bert(model, train, test, dict_users, args, call)
        if args.algorithm == 'CluSamp':
            ClusterSampling_bert(model, train, test, dict_users, args, call)
        if args.algorithm == 'Moon':
            Moon_bert(model, train, test, dict_users, args, call)
        if args.algorithm == 'FedMut':
            FedMut_bert(model, train, test, dict_users, args, call)
    else:
        if args.algorithm == 'FedAvg':
            FedAvg_bert(model, train, test, dict_users, args, call, label_dict)
        if args.algorithm == 'FedProx':
            FedProx_bert(model, train, test, dict_users, args, call, label_dict)
        if args.algorithm == 'FedCross':
            FedCross_bert(model, train, test, dict_users, args, call, label_dict)
        if args.algorithm == 'CluSamp':
            ClusterSampling_bert(model, train, test, dict_users, args, call, label_dict)
        if args.algorithm == 'Moon':
            Moon_bert(model, train, test, dict_users, args, call, label_dict)
        if args.algorithm == 'FedMut':
            FedMut_bert(model, train, test, dict_users, args, call, label_dict)
